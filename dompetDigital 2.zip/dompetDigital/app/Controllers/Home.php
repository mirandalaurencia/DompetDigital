<?php

namespace App\Controllers;

use App\Models\Category;
use App\Models\Transaction;
use App\Models\User;
use CodeIgniter\Controller;

class Home extends BaseController
{
    protected $session;

    function __construct()
    {
        $this->session = \Config\Services::session();
        $this->session->start();
    }

    // index / homepage
    public function index(){
        return view('login');
    }

    // logout
    public function logout(){
        unset($_SESSION['user_id'], $_SESSION['username'], $_SESSION['logged_in'], $_SESSION['role']);
        return view('login');
    }

    // Cek Auth User 
    public function cekAuth(){
        $NameModel = new User();
        $user_name = $this->request->getPost('name');
        $user_pass = $this->request->getPost('pass');
        $array = ['user_name' => $user_name, 'user_pass' => $user_pass];
        $data['user'] = $NameModel->where($array)->first();
        if ($data['user'] === '' || $data['user'] == NULL) {
            echo "<script>alert('User tidak ditemukan.');</script>";
            return $this->response->redirect(site_url('/'));
        } else {
            $newdata = [
                'user_id'  => $data['user']['user_id'],
                'username'  => $user_name,
                'logged_in' => TRUE,
                'role' => $data['user']['user_role']
            ];
            $this->session->set($newdata); // setting session data
            echo "<script>alert('Welcome');</script>";
            return $this->response->redirect(site_url('/welcome'));
        }
    }
    
    // welcome
    public function welcome(){
        $TransModel = new Transaction();
        $kredit = $TransModel->selectSum('trans_amount', 'kredit')->where('trans_type', 'K')->where('trans_verified', 'Y')->first();
        $debit = $TransModel->selectSum('trans_amount', 'debit')->where('trans_type', 'D')->where('trans_verified', 'Y')->first();
        $data['grand_total'] = $debit['debit']-$kredit['kredit'];
        return view('welcome', $data);
    }

    // view list transaction type page
    public function transaction_type(){
        return view('transaction_type');
    }

    // view transaction input page
    public function transaction_input($add = null, $trans_id = null){
        $NameModel = new Category();
        $data['cats'] = $NameModel->findAll();
        if ($add == 1) {
            $TransModel = new Transaction();
            $data['trans'] = $TransModel->where('trans_id', $trans_id)->first();
        } else {
            if ($trans_id == 1) {
                $trans_type = 'D';
            } else {
                $trans_type = 'K';
            }
            $data['trans_type'] = $trans_type;
        }
        return view('transaction_input', $data);
    }

    // view list transaction page
    public function transaction($verify=null){
        $TransModel = new Transaction();
        if ($verify != null) {
            $data['trans'] = $TransModel->join('category', 'category.cat_id=transaction.trans_cat_id')->where('transaction.trans_verified', 'N')->findAll();
        } else {
            $data['trans'] = $TransModel->join('category', 'category.cat_id=transaction.trans_cat_id')->findAll();
        }
        return view('transaction', $data);
    }
 
    // add data
    public function store() {
        $NameModel = new Transaction();
        $data = [
            'trans_user_id' => $this->session->get('user_id'),
            'trans_cat_id' => $this->request->getPost('cat'),
            'trans_type' => $this->request->getPost('trans_type'),
            'trans_desc' => $this->request->getPost('cat'),
            'trans_amount'  => $this->request->getPost('amount'),
            'trans_note'  => $this->request->getPost('note'),
            'trans_date' => $this->request->getPost('date'),
            'trans_verified'  => 'N',
            'trans_verified_id' => NULL,
            'trans_verified_date' => NULL
        ];
        $NameModel->insert($data);
        return $this->response->redirect(site_url('/transaction'));
    }

    // verify transaction
    public function verify($id = null){
        $date = date('Y-m-d');
        $NameModel = new Transaction();
        $data = [
            'trans_verified' => 'Y',
            'trans_verified_id' => 3,
            'trans_verified_date'  => $date,
        ];
        $NameModel->update($id, $data);
        return $this->response->redirect(site_url('/transaction'));
    }
 
    // delete transaction
    public function delete($id = null){
        $NameModel = new Transaction();
        $data['user'] = $NameModel->where('trans_id', $id)->delete($id);
        return $this->response->redirect(site_url('/transaction'));
    }

    // edit transaction
    public function edit($id = null){
        $NameModel = new Transaction();
        $data = [
            'trans_cat_id' => $this->request->getPost('cat'),
            'trans_desc' => $this->request->getPost('cat'),
            'trans_amount'  => $this->request->getPost('amount'),
            'trans_note'  => $this->request->getPost('note'),
            'trans_date' => $this->request->getPost('date')
        ];
        $data['trans'] = $NameModel->update($id, $data);
        return $this->response->redirect(site_url('/transaction'));
    }
}
