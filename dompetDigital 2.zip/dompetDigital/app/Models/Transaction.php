<?php 
namespace App\Models;
use CodeIgniter\Model;

class Transaction extends Model
{
    protected $table = 'transaction';

    protected $primaryKey = 'trans_id';
    
    protected $allowedFields = ['trans_id', 'trans_user_id', 'trans_cat_id', 'trans_type','trans_desc', 'trans_note','trans_date', 'trans_amount', 'trans_verified', 'trans_verified_id', 'trans_verified_date'];

    
}