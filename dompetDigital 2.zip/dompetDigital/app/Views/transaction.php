<html lang="en">
	<head>
		<title>Dompet Digital</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet"
			href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"
			integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk"
			crossorigin="anonymous">

		<style type="text/css">
		.title
		{
			padding: 3rem 1.5rem;
		}

		article
		{
			padding: 1.5rem 1.5rem;
		}
		</style>
	</head>
   <body>
		<main role="main" class="container">
			<div class="title">
				<h1>
					Dompet Digital
					<small class="text-muted">Transaction List</small>
				</h1>
			</div>
         <a href="<?php echo site_url('welcome');?>" class="btn btn-dark">Back to Dashboard</a>
         <a href="<?php echo site_url('transaction_type');?>" class="btn btn-primary">Add Transaction</a>
         <div class="mt-3">
            <br>
            <table class="table table-bordered" id="trans-list">
               <thead>
                  <tr>
                     <th>ID</th>
                     <th>Category</th>
                     <th>Type</th>
                     <th>Date</th>
                     <th>Amount</th>
                     <th>Note</th>
                     <th>Verified</th>
                     <th>Action</th>
                  </tr>
               </thead>
               <tbody>
                  <?php if($trans): ?>
                  <?php foreach($trans as $t): ?>
                  <tr>
                     <td><?php echo $t['trans_id']; ?></td>
                     <td><?php echo $t['cat_name']; ?></td>
                     <?php if($t['trans_type'] == 'K'): ?>
                        <td>Pengeluaran</td>
                     <?php else: ?>
                        <td>Pemasukan</td>
                     <?php endif; ?>
                     <td><?php echo $t['trans_date']; ?></td>
                     <td><?php echo $t['trans_amount']; ?></td>
                     <td><?php echo $t['tarns_note']; ?></td>
                     <td><?php echo $t['trans_verified']; ?></td>
                     <td>
                           <?php if($t['trans_verified'] == 'N'): ?>
                              <a href="<?php echo base_url('verify/'.$t['trans_id']);?>" class="btn btn-primary">Verify</a>
                              <a href="<?php echo site_url('transaction_edit/1/'.$t['trans_id']);?>" class="btn btn-warning">Edit</a>
                              <a href="<?php echo base_url('delete/'.$t['trans_id']);?>" class="btn btn-danger">Delete</a>
                           <?php endif; ?>
                     </td>
                  </tr>
                  <?php endforeach; ?>
                  <?php endif; ?>
               </tbody>
            </table>
         </div>
      </main>
 
      <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
      <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">
      <script type="text/javascript" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
      <script>
         $(document).ready( function () {
            $('#trans-list').DataTable();
      } );
      </script>
      <br>
      <footer>
			<p class="text-center">&copy; 2022 Dompet Digital</p>
		</footer>
   </body>
</html>