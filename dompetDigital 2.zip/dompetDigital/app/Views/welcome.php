<html lang="en">
	<head>
		<title>Dompet Digital</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
		<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>

		<style type="text/css">
		.title
		{
			padding: 3rem 1.5rem;
		}

		article
		{
			padding: 1.5rem 1.5rem;
		}
		</style>
	</head>

	<body>
		<?php
			$local_session = \Config\Services::session();
		?>
		<main role="main" class="container">
			<div class="title">
				<h1>
					Dompet Digital
					<small class="text-muted">Dashboard</small>
				</h1>
			</div>
			<h2>Welcome, <?php echo $local_session->get('username'); ?></h2>
			<br>
			<div class="col-md-6 p2 card" style="width:350px">
				<div class="card-body">
				<h4 class="card-title">Your balance</h4>
				<?php if($grand_total<0): ?>
					<p class="card-text"><h4 style="color: red"><?php echo $grand_total; ?></h4></p>
				<?php else: ?>
					<p class="card-text"><h4><?php echo $grand_total; ?></h4></p>
				<?php endif; ?>
				</div>
			</div>
			<br>
			<div class="row">
				<div class="col-md-6 d-inline p-2 card" style="width:300px">
					<div class="card-body">
						<h4 class="card-title">Transaction</h4>
						<p class="card-text">To know transactions list</p>
						<div class="row">
							<div class="col-md-6">
								<a href="<?php echo site_url('/transaction');?>" class="btn btn-primary" style="width:100%">List Transaction</a>
							</div>
							<?php if($local_session->get('role') == 2): ?>
								<div class="col-md-6">
									<a href="<?php echo site_url('/transaction/N');?>" class="btn btn-danger" style="width:100%">List Transaction Outstanding</a>
								</div>
							<?php endif; ?>
						</div>
					</div>
				</div>
				<?php if($local_session->get('role') == 2): ?>
					<div class="col-md-6 d-inline p-2 card" style="width:300px">
						<div class="card-body">
						<h4 class="card-title">Report</h4>
						<p class="card-text">To know report</p>
						<div class="row">
							<div class="col-md-6">
								<a href="<?php echo site_url('/pengeluaran_rpt');?>" class="btn btn-info" style="width:100%">Report Pemasukan</a>
							</div>
							<div class="col-md-6">
								<a href="<?php echo site_url('/pemasukan_rpt');?>" class="btn btn-info" style="width:100%">Report Pengeluaran</a>
							</div>
						</div>
						</div>
					</div>
				<?php endif; ?>
			</div>
			<br><br>
			<a href="<?php echo site_url('/logout');?>" class="btn btn-dark">Logout</a>
		</main>

		<footer>
			<p class="text-center">&copy; 2022 Dompet Digital</p>
		</footer>
	</body>
</html>