<html lang="en">
	<head>
		<title>Dompet Digital</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet"
			href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"
			integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk"
			crossorigin="anonymous">

		<style type="text/css">
		.title
		{
			padding: 3rem 1.5rem;
		}

		article
		{
			padding: 1.5rem 1.5rem;
		}
		</style>
	</head>

	<body>
		<main role="main" class="container">
			<div class="title">
				<h1>
					Dompet Digital
					<small class="text-muted">Input Transaction</small>
				</h1>
			</div>
			<?php if(!isset($trans)): ?>
				<form method="post" action="<?php echo base_url('home/store') ?>">
					<input type="text" name="trans_type" value="<?php echo $trans_type; ?>"><br>
					Date: <br><input type="date" name="date" value="<?php echo date('Y-m-d') ?>"><br>
					Category: <br>
					<select class="form-control" name="cat">
						<?php 
							foreach($cats as $row)
							{ 
								echo '<option value="'.$row['cat_id'].'">'.$row['cat_name'].'</option>';
							}
						?>
					</select>
					<br>
					Nominal: <br><input type="number" name="amount"><br>
					Note: <br><input type="text" name="note"><br>
					<br>
					<button type="submit" class="btn btn-primary">Add</button>
				</form>
				<?php else: ?>
				<form method="post" action="<?php echo site_url('edit/'.$trans['trans_id']) ?>">
					<input type="text" name="trans_type" value="<?php echo $trans['trans_type']; ?>"><br>
					Date: <br><input type="date" name="date" value="<?php echo $trans['trans_date'] ?>"><br>
					Category: <br>
					<select class="form-control" name="cat">
						<?php 
							foreach($cats as $row)
							{ 
								echo '<option value="'.$row['cat_id'].'">'.$row['cat_name'].'</option>';
							}
						?>
					</select>
					<br>
					Nominal: <br><input type="number" name="amount" value="<?php echo $trans['trans_amount']; ?>"><br>
					Note: <br><input type="text" name="note" value="<?php echo $trans['trans_note']; ?>"><br>
					<br>
					<button type="submit" class="btn btn-primary">Update</button>
				</form>
				<?php endif; ?>
         	<a href="<?php echo site_url('transaction_type');?>" class="btn btn-danger">Cancel</a>
		</main>

		<footer>
			<p class="text-center">&copy; 2022 Dompet Digital</p>
		</footer>
	</body>
</html>