<html lang="en">
	<head>
		<title>Dompet Digital</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet"
			href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"
			integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk"
			crossorigin="anonymous">

		<style type="text/css">
		.title
		{
			padding: 3rem 1.5rem;
		}

		article
		{
			padding: 1.5rem 1.5rem;
		}
		</style>
	</head>

	<body>
		<main role="main" class="container">
			<div class="title">
				<h1>
					Dompet Digital
					<small class="text-muted">Login</small>
				</h1>
			</div>
			<form method="post" action="<?php echo base_url('home/cekAuth') ?>">
            Username: <br><input type="text" name="name"><br>
            Password: <br><input type="password" name="pass"><br>
				<br>
				<button type="submit" class="btn btn-primary">Login</button>
			</form>
		</main>

		<footer>
			<p class="text-center">&copy; 2022 Dompet Digital</p>
		</footer>
	</body>
</html>